interface Banda {
    id?: number;
    nombre?: string;
    fecha?: string;
}
export default Banda;
