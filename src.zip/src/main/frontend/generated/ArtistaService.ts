import { EndpointRequestInit as EndpointRequestInit_1 } from "@vaadin/hilla-frontend";
import client_1 from "./connect-client.default.js";
async function aupdateArtista_1(id: number | undefined, nombre: string | undefined, nacionalidad: string | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("ArtistaService", "aupdateArtista", { id, nombre, nacionalidad }, init); }
async function createArtista_1(nombre: string | undefined, nacionalidad: string | undefined, init?: EndpointRequestInit_1): Promise<void> { return client_1.call("ArtistaService", "createArtista", { nombre, nacionalidad }, init); }
async function listArtista_1(init?: EndpointRequestInit_1): Promise<Array<Record<string, unknown> | undefined> | undefined> { return client_1.call("ArtistaService", "listArtista", {}, init); }
async function listCountry_1(init?: EndpointRequestInit_1): Promise<Array<string | undefined> | undefined> { return client_1.call("ArtistaService", "listCountry", {}, init); }
async function listRolArtista_1(init?: EndpointRequestInit_1): Promise<Array<string | undefined> | undefined> { return client_1.call("ArtistaService", "listRolArtista", {}, init); }
export { aupdateArtista_1 as aupdateArtista, createArtista_1 as createArtista, listArtista_1 as listArtista, listCountry_1 as listCountry, listRolArtista_1 as listRolArtista };
