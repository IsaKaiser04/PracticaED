


if (!document['_vaadintheme_default_componentCss']) {
  
  document['_vaadintheme_default_componentCss'] = true;
}

if (import.meta.hot) {
  import.meta.hot.accept((module) => {
    window.location.reload();
  });
}

