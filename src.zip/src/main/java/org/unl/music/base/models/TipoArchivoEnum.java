package org.unl.music.base.models;

public enum TipoArchivoEnum {
    FISICO, VIRTUAL;
}
